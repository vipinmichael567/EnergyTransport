/*============================================================================
 * User subroutines for input of calculation parameters.
 *============================================================================*/

/* Code_Saturne version 4.0.1 */

/*
  This file is part of Code_Saturne, a general-purpose CFD tool.

  Copyright (C) 1998-2015 EDF S.A.

  This program is free software; you can redistribute it and/or modify it under
  the terms of the GNU General Public License as published by the Free Software
  Foundation; either version 2 of the License, or (at your option) any later
  version.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
  details.

  You should have received a copy of the GNU General Public License along with
  this program; if not, write to the Free Software Foundation, Inc., 51 Franklin
  Street, Fifth Floor, Boston, MA 02110-1301, USA.
*/

/*----------------------------------------------------------------------------*/

#include "cs_defs.h"

/*----------------------------------------------------------------------------
 * Standard C library headers
 *----------------------------------------------------------------------------*/

#include <assert.h>
#include <math.h>
#include <string.h>

#if defined(HAVE_MPI)
#include <mpi.h>
#endif

/*----------------------------------------------------------------------------
 * PLE library headers
 *----------------------------------------------------------------------------*/

#include <ple_coupling.h>

/*----------------------------------------------------------------------------
 *  Local headers
 *----------------------------------------------------------------------------*/

#include "bft_mem.h"
#include "bft_error.h"
#include "bft_printf.h"

#include "fvm_writer.h"

#include "cs_base.h"
#include "cs_field.h"
#include "cs_gui_util.h"
#include "cs_field_pointer.h"
#include "cs_field_operator.h"
#include "cs_math.h"
#include "cs_mesh.h"
#include "cs_mesh_location.h"
#include "cs_mesh_quantities.h"
#include "cs_halo.h"
#include "cs_halo_perio.h"
#include "cs_log.h"
#include "cs_multigrid.h"
#include "cs_parameters.h"
#include "cs_physical_constants.h"
#include "cs_prototypes.h"
#include "cs_rotation.h"
#include "cs_sles.h"
#include "cs_sles_it.h"
#include "cs_time_moment.h"
#include "cs_time_step.h"
#include "cs_turbomachinery.h"
#include "cs_selector.h"

#include "cs_post.h"

/*----------------------------------------------------------------------------
 *  Header for the current file
 *----------------------------------------------------------------------------*/

#include "cs_prototypes.h"

/*----------------------------------------------------------------------------*/

BEGIN_C_DECLS

/*============================================================================
 * User function definitions
 *============================================================================*/

/*----------------------------------------------------------------------------*/
/*!
 * \brief Select physical model options, including user fields.
 *
 * This function is called at the earliest stages of the data setup,
 * so field ids are not available yet.
 */
/*----------------------------------------------------------------------------*/

void
cs_user_model(void)
{
  /* If the GUI is used, user fields should preferably be defined with the GUI,
     so that associated numerical options, boundary conditions, initializations,
     and such may also be defined using the GUI. */

  if (cs_gui_file_is_loaded())
    return;

  /*--------------------------------------------------------------------------*/

  /* Example: add 2 scalar variables ("species" in the GUI nomenclature).
   *
   * Note that at this (very early) stage of the data setup, fields are
   * not defined yet. Associated fields will be defined later (after
   * model-defined fields) in the same order as that used here, and
   * after user-defined variables defined throught the GUI, if used.
   *
   * Currently, only 1d (scalar) fields are handled.
   *
   * parameters for cs_parameters_add_variable():
   *   name             <-- name of variable and associated field
   *   dim              <-- variable dimension
   */

  if (true) {
    cs_parameters_add_variable("Tracer", 1);
    cs_parameters_add_variable("Work", 1);
  }



  /*--------------------------------------------------------------------------*/

  /* Example: add the variance of a user variable.
   *
   * parameters for cs_parameters_add_variable_variance():
   *   name          <-- name of variance and associated field
   *   variable_name <-- name of associated variable
   */

  if (false) {
    cs_parameters_add_variable_variance("Tracer_Variance",
                                        "Tracer");
  }

  /*--------------------------------------------------------------------------*/

  /* Example: add a user property defined on boundary faces.
   *
   * parameters for cs_parameters_add_property():
   *   name        <-- name of property and associated field
   *   dim         <-- property dimension
   *   location_id <-- id of associated mesh location, which must be one of:
   *                     CS_MESH_LOCATION_CELLS
   *                     CS_MESH_LOCATION_INTERIOR_FACES
   *                     CS_MESH_LOCATION_BOUNDARY_FACES
   *                     CS_MESH_LOCATION_VERTICES
   */

  if (true) {
    cs_parameters_add_property("pwork",
                               1,
                               CS_MESH_LOCATION_CELLS);

   }
  
  if (true) {
    cs_parameters_add_property("viscous_term",
                               1,
                               CS_MESH_LOCATION_CELLS);

   }
      

  if (true) {
    cs_parameters_add_property("kvisc",
                               1,
                               CS_MESH_LOCATION_CELLS);
   } 

  if (true) {
    cs_parameters_add_property("yield_stress",
                               1,
                               CS_MESH_LOCATION_CELLS);
   }
   
  if (true) {
    cs_parameters_add_property("yield_strain",
                               1,
                               CS_MESH_LOCATION_CELLS);
   }
   
  if (true) {
    cs_parameters_add_property("strain_invariance",
                               1,
                               CS_MESH_LOCATION_CELLS);
   }

  if (true) {
    cs_parameters_add_property("tau11",
                               1,
                               CS_MESH_LOCATION_CELLS);
   }

  if (true) {
    cs_parameters_add_property("tau12",
                               1,
                               CS_MESH_LOCATION_CELLS);
   }

  if (true) {
    cs_parameters_add_property("tau13",
                               1,
                               CS_MESH_LOCATION_CELLS);
   }

  if (true) {
    cs_parameters_add_property("tau21",
                               1,
                               CS_MESH_LOCATION_CELLS);
   }

  if (true) {
    cs_parameters_add_property("tau22",
                               1,
                               CS_MESH_LOCATION_CELLS);
   }

  if (true) {
    cs_parameters_add_property("tau23",
                               1,
                               CS_MESH_LOCATION_CELLS);
   }

  if (true) {
    cs_parameters_add_property("tau31",
                               1,
                               CS_MESH_LOCATION_CELLS);
   }

  if (true) {
    cs_parameters_add_property("tau32",
                               1,
                               CS_MESH_LOCATION_CELLS);
   }

  if (true) {
    cs_parameters_add_property("tau33",
                               1,
                               CS_MESH_LOCATION_CELLS);
   }

}

/*----------------------------------------------------------------------------*/
/*!
 * \brief Define linear solver options.
 *
 * This function is called at the setup stage, once user and most model-based
 * fields are defined.
 *
 * Available native iterative linear solvers include conjugate gradient,
 * Jacobi, BiCGStab, BiCGStab2, and GMRES. For symmetric linear systems,
 * an algebraic multigrid solver is available (and recommended).
 *
 * External solvers may also be setup using this function, the cs_sles_t
 * mechanism alowing such through user-define functions.
 */
/*----------------------------------------------------------------------------*/

void
cs_user_linear_solvers(void)
{

}

/*----------------------------------------------------------------------------*/
/*!
 * \brief Define time moments.
 *
 * This function is called at the setup stage, once user and most model-based
 * fields are defined, and before fine control of field output options
 * is defined.
 */
/*----------------------------------------------------------------------------*/

void
cs_user_time_moments(void)
{
 {
    /* Moment <U> calculated starting from time step 1000. */

    /*! [tmom_u] */
    int moment_f_id[] = {CS_F_(u)->id};
    int moment_c_id[] = {0};
    int n_fields = 1;
    cs_time_moment_define_by_field_ids("u_mean",
                                       n_fields,
                                       moment_f_id,
                                       moment_c_id,
                                       CS_TIME_MOMENT_MEAN,
                                       15600, /* nt_start */
                                       -1,   /* t_start */
                                       CS_TIME_MOMENT_RESTART_AUTO,
                                       NULL);
    /*! [tmom_u] */
  }

{
    /* Moment <U> calculated starting from time step 1000. */

    /*! [tmom_u] */
    int moment_f_id[] = {CS_F_(u)->id};
    int moment_c_id[] = {1};
    int n_fields = 1;
    cs_time_moment_define_by_field_ids("v_mean",
                                       n_fields,
                                       moment_f_id,
                                       moment_c_id,
                                       CS_TIME_MOMENT_MEAN,
                                       15600, /* nt_start */
                                       -1,   /* t_start */
                                       CS_TIME_MOMENT_RESTART_AUTO,
                                       NULL);
    /*! [tmom_u] */
  }

{
    /* Moment <U> calculated starting from time step 1000. */

    /*! [tmom_u] */
    int moment_f_id[] = {CS_F_(u)->id};
    int moment_c_id[] = {2};
    int n_fields = 1;
    cs_time_moment_define_by_field_ids("w_mean",
                                       n_fields,
                                       moment_f_id,
                                       moment_c_id,
                                       CS_TIME_MOMENT_MEAN,
                                       15600, /* nt_start */
                                       -1,   /* t_start */
                                       CS_TIME_MOMENT_RESTART_AUTO,
                                       NULL);
    /*! [tmom_u] */
  }

{
    /* Moment <viscosity> calculated starting from time step 1000. */

    /*! [tmom_u] */
    int moment_f_id[] = {CS_F_(mu)->id};
    int moment_c_id[] = {-1};
    int n_fields = 1;
    cs_time_moment_define_by_field_ids("mu_mean",
                                       n_fields,
                                       moment_f_id,
                                       moment_c_id,
                                       CS_TIME_MOMENT_MEAN,
                                       15600, /* nt_start */
                                       -1,   /* t_start */
                                       CS_TIME_MOMENT_RESTART_AUTO,
                                       NULL);
    /*! [tmom_u] */
  }


{
    /* Moment <viscosity> calculated starting from time step 1000. */

    /*! [tmom_u] */
    int moment_f_id[] = {cs_field_by_name("Work")->id};
    int moment_c_id[] = {-1};
    int n_fields = 1;
    cs_time_moment_define_by_field_ids("Work_mean",
                                       n_fields,
                                       moment_f_id,
                                       moment_c_id,
                                       CS_TIME_MOMENT_MEAN,
                                       15600, /* nt_start */
                                       -1,   /* t_start */
                                       CS_TIME_MOMENT_RESTART_AUTO,
                                       NULL);
    /*! [tmom_u] */
  }








//   if (cs_field_by_name("Work") !=NULL) /*indexes in C begin at 0, while indexes in fortran begin at 1 */
//   {
//     /* Moment <Work> */
//
//
//     int moment_f_id[] = {cs_field_by_name("Work")->id};
//     int moment_c_id[] = {-1};
//     int n_fields = 1;
//     cs_time_moment_define_by_field_ids("Work_avg",
//                                        n_fields,
//                                        moment_f_id,
//                                        moment_c_id,
//                                        CS_TIME_MOMENT_MEAN,
//cs_glob_time_step->nt_prev + 3000,     /* nt_start */
//                                        -1,   /* t_start */
//CS_TIME_MOMENT_RESTART_AUTO,
//                                        NULL);
//
//   }




//{
//    /* Moment <UU> calculated starting from time step 1000. */
//
//    /*! [tmom_u] */
//    int moment_f_id[] = {CS_F_(u)->id};
//    int moment_c_id[] = {0, 0};
//    int n_fields = 2;
//    cs_time_moment_define_by_field_ids("uu_mean",
//                                       n_fields,
//                                       moment_f_id,
//                                       moment_c_id,
//                                       CS_TIME_MOMENT_MEAN,
//                                       1, /* nt_start */
//                                       -1,   /* t_start */
//                                       CS_TIME_MOMENT_RESTART_AUTO,
//                                       NULL);
//    /*! [tmom_u] */
//  }
//
//
//{
//    /* Moment <UU> calculated starting from time step 1000. */
//
//    /*! [tmom_u] */
//    int moment_f_id[] = {CS_F_(u)->id};
//    int moment_c_id[] = {1, 1};
//    int n_fields = 2;
//    cs_time_moment_define_by_field_ids("vv_mean",
//                                       n_fields,
//                                       moment_f_id,
//                                       moment_c_id,
//                                       CS_TIME_MOMENT_MEAN,
//                                       1, /* nt_start */
//                                       -1,   /* t_start */
//                                       CS_TIME_MOMENT_RESTART_AUTO,
//                                       NULL);
//    /*! [tmom_u] */
//  }
//
//{
//    /* Moment <UU> calculated starting from time step 1000. */
//
//    /*! [tmom_u] */
//    int moment_f_id[] = {CS_F_(u)->id};
//    int moment_c_id[] = {2, 2};
//    int n_fields = 2;
//    cs_time_moment_define_by_field_ids("ww_mean",
//                                       n_fields,
//                                       moment_f_id,
//                                       moment_c_id,
//                                       CS_TIME_MOMENT_MEAN,
//                                       1, /* nt_start */
//                                       -1,   /* t_start */
//                                       CS_TIME_MOMENT_RESTART_AUTO,
//                                       NULL);
//    /*! [tmom_u] */
//  }
//
// 

}

/*----------------------------------------------------------------------------*/

END_C_DECLS
